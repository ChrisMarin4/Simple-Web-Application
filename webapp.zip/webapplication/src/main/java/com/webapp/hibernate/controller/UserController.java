package com.webapp.hibernate.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.webapp.hibernate.dao.UserDao;
import com.webapp.hibernate.model.User;


@WebServlet ("/register")
public class UserController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	private UserDao userDao;
	
	public void init() {
		userDao = new UserDao();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		    throws ServletException, IOException {
		        register(request, response);
		    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		    throws ServletException, IOException {
		        response.sendRedirect("index.jsp");
		    }

	 private void register(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		 	String name = request.getParameter("name");
	        String surname = request.getParameter("surname");
	        String gender = request.getParameter("gender");
	        String birthdate = request.getParameter("birthdate");
	        String work_address = request.getParameter("work_address");
	        String home_address = request.getParameter("home_address");

		 	
	        User user = new User();
	        user.setName(name);
	        user.setSurname(surname);
	        user.setGender(gender);
	        user.setBrithdate(birthdate);
	        user.setWork_address(work_address);
	        user.setHome_address(home_address);
	       
	        userDao.saveUser(user);

	        RequestDispatcher dispatcher = request.getRequestDispatcher("homepage.jsp");
	        dispatcher.forward(request, response);
	        
	 }
}
